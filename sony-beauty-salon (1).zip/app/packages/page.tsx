"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { PageTransition } from "../components/page-transition"
import { packages } from "../data/packages"
import { Check, Crown, Star } from "lucide-react"

export default function PackagesPage() {
  const handleBookAppointment = () => {
    window.open("https://forms.gle/XsvtBWLNAWkJsj4bA", "_blank")
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-rose-50">
        <div className="container mx-auto px-4 py-20">
          {/* Hero Section */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-6">
              Beauty Packages
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Choose from our carefully curated beauty packages designed to give you the complete makeover experience at
              unbeatable prices.
            </p>
          </motion.div>

          {/* Packages Grid */}
          <div className="grid lg:grid-cols-3 gap-8">
            {packages.map((pkg, index) => (
              <motion.div
                key={pkg.id}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: index * 0.1, duration: 0.8 }}
                className={pkg.popular ? "lg:scale-105" : ""}
              >
                <Card
                  className={`h-full relative ${
                    pkg.popular ? "ring-2 ring-purple-500 shadow-xl" : "hover:shadow-lg"
                  } transition-all duration-300`}
                >
                  {pkg.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-gradient-to-r from-pink-500 to-purple-600 text-white px-4 py-2 text-sm font-semibold">
                        <Star className="w-4 h-4 mr-1" />
                        Most Popular
                      </Badge>
                    </div>
                  )}

                  <CardContent className="p-8">
                    {/* Package Header */}
                    <div className="text-center mb-8">
                      <div className="flex justify-center mb-4">
                        <Crown className={`w-12 h-12 ${pkg.popular ? "text-purple-600" : "text-gray-400"}`} />
                      </div>
                      <h3 className="text-2xl font-bold text-gray-800 mb-2">{pkg.name}</h3>
                      <div className="text-4xl font-bold text-purple-600 mb-2">₹{pkg.price.toLocaleString()}</div>
                      <p className="text-gray-600 text-sm">{pkg.description}</p>
                    </div>

                    {/* Services List */}
                    <div className="space-y-3 mb-8">
                      {pkg.services.map((service, serviceIndex) => (
                        <div key={serviceIndex} className="flex items-start">
                          <Check className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700 text-sm">{service}</span>
                        </div>
                      ))}
                    </div>

                    {/* Book Button */}
                    <Button
                      className={`w-full ${
                        pkg.popular
                          ? "bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                          : "bg-gray-800 hover:bg-gray-900"
                      } text-white py-3`}
                      onClick={handleBookAppointment}
                    >
                      Book This Package
                    </Button>

                    {/* Savings Badge */}
                    {pkg.popular && (
                      <div className="text-center mt-4">
                        <Badge variant="outline" className="text-green-600 border-green-600">
                          Save up to 40% vs individual services
                        </Badge>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Additional Info */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="mt-16 text-center"
          >
            <Card className="p-8 bg-gradient-to-r from-pink-100 to-purple-100">
              <CardContent>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Why Choose Our Packages?</h3>
                <div className="grid md:grid-cols-3 gap-6 text-center">
                  <div>
                    <div className="text-3xl mb-2">💰</div>
                    <h4 className="font-semibold mb-2">Best Value</h4>
                    <p className="text-sm text-gray-600">Save significantly compared to individual services</p>
                  </div>
                  <div>
                    <div className="text-3xl mb-2">⏰</div>
                    <h4 className="font-semibold mb-2">Time Efficient</h4>
                    <p className="text-sm text-gray-600">Complete makeover in a single session</p>
                  </div>
                  <div>
                    <div className="text-3xl mb-2">✨</div>
                    <h4 className="font-semibold mb-2">Expert Curated</h4>
                    <p className="text-sm text-gray-600">Professionally designed combinations for best results</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </PageTransition>
  )
}
