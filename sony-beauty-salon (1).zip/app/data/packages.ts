export interface Package {
  id: string
  name: string
  price: number
  popular?: boolean
  services: string[]
  description: string
}

export const packages: Package[] = [
  {
    id: "basic-pack",
    name: "Basic Pack",
    price: 1699,
    description: "Essential beauty services for a fresh look",
    services: [
      "Hand Polish",
      "Hair Cut (U, V, Straight - choice of yours)",
      "Threading - Eyebrow, Upper Lip, Forehead, Chin",
      "Full Hand Honey Waxing",
      "Full Leg Honey Waxing",
      "Underarm Honey Waxing",
      "Basic Facial",
    ],
  },
  {
    id: "radiance-pack",
    name: "Radiance Pack",
    price: 1899,
    popular: true,
    description: "Most popular package for complete beauty transformation",
    services: [
      "Wine or Fruit Facial",
      "Haircut (Butterfly or Layer – customer's choice)",
      "Threading: Eyebrow, Upper Lip, Forehead, Chin",
      "Full Hand Rica Waxing",
      "Underarm Rica Waxing",
      "Full Leg Rica Waxing",
      "Foot Massage – 15 minutes",
      "Head Massage – 15 minutes",
    ],
  },
  {
    id: "elegance-pack",
    name: "Elegance Pack",
    price: 2299,
    description: "Premium services for an elegant makeover",
    services: [
      "O3 Facial",
      "Threading: Eyebrow, Upper Lip, Forehead, Chin",
      "Hand Polish",
      "Signature Manicure",
      "Signature Pedicure",
      "Full Hand Roll-On Waxing",
      "Underarm Roll-On Waxing",
      "Full Leg Roll-On Waxing",
      "Hair Color or Hair Spa (Hair color to be provided by customer)",
    ],
  },
  {
    id: "luxury-pack",
    name: "Luxury Pack",
    price: 2499,
    description: "Luxurious treatments for the ultimate pampering experience",
    services: [
      "Hydraboosting Facial",
      "Threading: Eyebrow, Upper Lip, Forehead, Chin",
      "Haircut (Feather, Layer, or Step)",
      "Full Hand Rica Waxing",
      "Underarm Rica Waxing",
      "Full Leg Rica Waxing",
      "Keratin Hair Spa or L'Oréal Dandruff Spa",
      "Spa Manicure",
      "Spa Pedicure",
    ],
  },
  {
    id: "royal-glow-pack",
    name: "Royal Glow Pack",
    price: 2999,
    description: "The ultimate royal treatment for complete transformation",
    services: [
      "Korean Facial",
      "Threading: Eyebrow, Upper Lip, Forehead, Chin",
      "Full Hand Roll-On Waxing",
      "Underarm Roll-On Waxing",
      "Full Leg Roll-On Waxing",
      "Back Polish or Back Massage",
      "Crystal Candle Spa Manicure",
      "Crystal Candle Spa Pedicure",
      "Hair Spa or Head Massage",
    ],
  },
]
