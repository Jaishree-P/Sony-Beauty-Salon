"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { PageTransition } from "../components/page-transition"
import { Phone, Mail, MapPin, Clock, MessageCircle, Calendar } from "lucide-react"

export default function ContactPage() {
  const handleBookAppointment = () => {
    window.open("https://forms.gle/XsvtBWLNAWkJsj4bA", "_blank")
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-rose-50">
        <div className="container mx-auto px-4 py-20">
          {/* Hero Section */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-6">
              Contact Us
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Ready to transform your beauty? Get in touch with us to book your appointment or ask any questions about
              our services.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <motion.div
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              <Card className="p-8">
                <CardContent>
                  <h2 className="text-2xl font-bold text-gray-800 mb-6">Send us a Message</h2>
                  <form className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                        <Input placeholder="Enter your first name" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                        <Input placeholder="Enter your last name" />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                      <Input type="email" placeholder="Enter your email" />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                      <Input type="tel" placeholder="Enter your phone number" />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Service Interested In</label>
                      <select className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        <option value="">Select a service</option>
                        <option value="basic-pack">Basic Pack</option>
                        <option value="radiance-pack">Radiance Pack</option>
                        <option value="elegance-pack">Elegance Pack</option>
                        <option value="luxury-pack">Luxury Pack</option>
                        <option value="royal-glow-pack">Royal Glow Pack</option>
                        <option value="individual">Individual Service</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                      <Textarea placeholder="Tell us about your requirements or any questions you have..." rows={4} />
                    </div>

                    <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white py-3">
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            {/* Contact Information */}
            <motion.div
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="space-y-8"
            >
              {/* Contact Details */}
              <Card className="p-8">
                <CardContent>
                  <h2 className="text-2xl font-bold text-gray-800 mb-6">Get in Touch</h2>
                  <div className="space-y-6">
                    <div className="flex items-center">
                      <Phone className="w-6 h-6 text-purple-600 mr-4" />
                      <div>
                        <p className="font-semibold text-gray-800">Phone</p>
                        <p className="text-gray-600">+91 98765 43210</p>
                      </div>
                    </div>

                    <div className="flex items-center">
                      <Mail className="w-6 h-6 text-purple-600 mr-4" />
                      <div>
                        <p className="font-semibold text-gray-800">Email</p>
                        <p className="text-gray-600">info@sonybeautysalon.com</p>
                      </div>
                    </div>

                    <div className="flex items-center">
                      <MapPin className="w-6 h-6 text-purple-600 mr-4" />
                      <div>
                        <p className="font-semibold text-gray-800">Service Area</p>
                        <p className="text-gray-600">Mumbai, Delhi, Bangalore & Pune</p>
                      </div>
                    </div>

                    <div className="flex items-center">
                      <Clock className="w-6 h-6 text-purple-600 mr-4" />
                      <div>
                        <p className="font-semibold text-gray-800">Working Hours</p>
                        <p className="text-gray-600">9:00 AM - 9:00 PM (All Days)</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Contact */}
              <Card className="p-8 bg-gradient-to-r from-pink-100 to-purple-100">
                <CardContent>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Quick Contact</h3>
                  <p className="text-gray-600 mb-6">
                    Need immediate assistance? Call us directly or send a WhatsApp message for instant support.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      WhatsApp
                    </Button>
                    <Button
                      className="flex-1 bg-purple-600 hover:bg-purple-700 text-white"
                      onClick={handleBookAppointment}
                    >
                      <Calendar className="w-4 h-4 mr-2" />
                      Book Now
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* FAQ */}
              <Card className="p-8">
                <CardContent>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Frequently Asked</h3>
                  <div className="space-y-4">
                    <div>
                      <p className="font-semibold text-gray-800 mb-1">How do I book an appointment?</p>
                      <p className="text-sm text-gray-600">
                        Call us or send a message through our contact form with your preferred date and time.
                      </p>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800 mb-1">Do you provide services on weekends?</p>
                      <p className="text-sm text-gray-600">
                        Yes, we provide services all 7 days of the week from 9 AM to 9 PM.
                      </p>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800 mb-1">What areas do you cover?</p>
                      <p className="text-sm text-gray-600">
                        We currently serve Mumbai, Delhi, Bangalore, and Pune with plans to expand soon.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </PageTransition>
  )
}
