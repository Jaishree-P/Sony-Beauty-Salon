"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Star, Send } from "lucide-react"

export function ReviewForm() {
  const [formData, setFormData] = useState({
    name: "",
    place: "",
    service: "",
    review: "",
    rating: 0,
  })

  const [hoveredRating, setHoveredRating] = useState(0)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the data to your backend
    console.log("Review submitted:", formData)
    alert("Thank you for your review! It will be published after verification.")
    setFormData({
      name: "",
      place: "",
      service: "",
      review: "",
      rating: 0,
    })
  }

  const services = [
    "Facial Treatment",
    "Hair Cut & Styling",
    "Manicure & Pedicure",
    "Threading",
    "Waxing",
    "Hair Spa",
    "Makeup",
    "Basic Pack",
    "Radiance Pack",
    "Elegance Pack",
    "Luxury Pack",
    "Royal Glow Pack",
  ]

  return (
    <Card className="sticky top-24">
      <CardContent className="p-6">
        <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">Write a Review</h3>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Your Name *</label>
            <Input
              required
              placeholder="Enter your name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>

          {/* Place */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Your Location *</label>
            <Input
              required
              placeholder="Enter your city/area"
              value={formData.place}
              onChange={(e) => setFormData({ ...formData, place: e.target.value })}
            />
          </div>

          {/* Service */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Service Availed *</label>
            <select
              required
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              value={formData.service}
              onChange={(e) => setFormData({ ...formData, service: e.target.value })}
            >
              <option value="">Select service</option>
              {services.map((service) => (
                <option key={service} value={service}>
                  {service}
                </option>
              ))}
            </select>
          </div>

          {/* Rating */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Rating *</label>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  className="focus:outline-none"
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  onClick={() => setFormData({ ...formData, rating: star })}
                >
                  <Star
                    className={`w-8 h-8 ${
                      star <= (hoveredRating || formData.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                    } transition-colors`}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Review */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">How was the service? *</label>
            <Textarea
              required
              placeholder="Share your experience with us..."
              rows={4}
              value={formData.review}
              onChange={(e) => setFormData({ ...formData, review: e.target.value })}
            />
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white"
          >
            <Send className="w-4 h-4 mr-2" />
            Submit Review
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
