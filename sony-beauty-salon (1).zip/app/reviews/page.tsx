"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { PageTransition } from "../components/page-transition"
import { ReviewForm } from "../components/review-form"
import { Star, Quote } from "lucide-react"
import Link from "next/link"

export default function ReviewsPage() {
  const handleBookAppointment = () => {
    window.open("https://forms.gle/XsvtBWLNAWkJsj4bA", "_blank")
  }

  const reviews = [
    {
      id: 1,
      name: "Priya Sharma",
      place: "Mumbai",
      rating: 5,
      comment:
        "Absolutely amazing service! The team was professional and the results exceeded my expectations. The convenience of home service is unmatched.",
      service: "Radiance Pack",
      date: "2 weeks ago",
    },
    {
      id: 2,
      name: "Anita Patel",
      place: "Delhi",
      rating: 5,
      comment:
        "I have been using Sony Beauty Salon for over a year now. Consistent quality and excellent customer service. Highly recommended!",
      service: "Korean Facial",
      date: "1 month ago",
    },
    {
      id: 3,
      name: "Meera Gupta",
      place: "Bangalore",
      rating: 5,
      comment:
        "The Royal Glow Pack was worth every penny. I felt like a queen after the treatment. The staff is so skilled and friendly.",
      service: "Royal Glow Pack",
      date: "3 weeks ago",
    },
    {
      id: 4,
      name: "Kavya Reddy",
      place: "Pune",
      rating: 5,
      comment:
        "Perfect for busy professionals like me. Quality service at home saves so much time. The facial was rejuvenating!",
      service: "O3 Facial",
      date: "1 week ago",
    },
    {
      id: 5,
      name: "Sneha Joshi",
      place: "Mumbai",
      rating: 5,
      comment:
        "Excellent hygiene standards and premium products. The manicure and pedicure were done to perfection. Will definitely book again.",
      service: "Spa Manicure & Pedicure",
      date: "2 weeks ago",
    },
    {
      id: 6,
      name: "Ritu Singh",
      place: "Delhi",
      rating: 5,
      comment:
        "The hair spa treatment was incredible. My hair feels so soft and healthy now. Great value for money with the packages.",
      service: "Keratin Hair Spa",
      date: "1 month ago",
    },
  ]

  const averageRating = reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-rose-50">
        <div className="container mx-auto px-4 py-20">
          {/* Hero Section */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-6">
              Customer Reviews
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Don't just take our word for it. Here's what our satisfied customers have to say about their experience
              with Sony Beauty Salon.
            </p>

            {/* Rating Summary */}
            <div className="flex items-center justify-center gap-4 mb-8">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <span className="text-2xl font-bold text-gray-800">{averageRating.toFixed(1)}</span>
              <span className="text-gray-600">({reviews.length} reviews)</span>
            </div>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Reviews Grid */}
            <div className="lg:col-span-2">
              <div className="grid md:grid-cols-2 gap-6">
                {reviews.map((review, index) => (
                  <motion.div
                    key={review.id}
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: index * 0.1, duration: 0.8 }}
                  >
                    <Card className="h-full hover:shadow-lg transition-shadow duration-300">
                      <CardContent className="p-6">
                        {/* Quote Icon */}
                        <div className="flex justify-center mb-4">
                          <Quote className="w-8 h-8 text-purple-300" />
                        </div>

                        {/* Rating */}
                        <div className="flex justify-center mb-4">
                          {[...Array(review.rating)].map((_, i) => (
                            <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                          ))}
                        </div>

                        {/* Review Text */}
                        <p className="text-gray-600 text-center mb-6 italic">"{review.comment}"</p>

                        {/* Customer Info */}
                        <div className="text-center border-t pt-4">
                          <h4 className="font-semibold text-gray-800">{review.name}</h4>
                          <p className="text-sm text-gray-500">{review.place}</p>
                          <p className="text-sm text-purple-600 font-medium">{review.service}</p>
                          <p className="text-xs text-gray-500 mt-1">{review.date}</p>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Review Form Sidebar */}
            <div className="lg:col-span-1">
              <motion.div
                initial={{ x: 50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.4, duration: 0.8 }}
              >
                <ReviewForm />
              </motion.div>
            </div>
          </div>

          {/* Call to Action */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="mt-16 text-center"
          >
            <Card className="p-8 bg-gradient-to-r from-pink-100 to-purple-100">
              <CardContent>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">
                  Ready to Experience the Sony Beauty Difference?
                </h3>
                <p className="text-gray-600 mb-6">
                  Join thousands of satisfied customers who trust us with their beauty needs.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleBookAppointment}
                    className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-8 py-3 rounded-lg font-semibold"
                  >
                    Book Appointment
                  </motion.button>
                  <Link href="/packages">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="border-2 border-purple-300 text-purple-600 hover:bg-purple-50 px-8 py-3 rounded-lg font-semibold"
                    >
                      View Packages
                    </motion.button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </PageTransition>
  )
}
