"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { PageTransition } from "../components/page-transition"
import { Award, Users, Clock, Heart, Calendar, Phone, MapPin, CheckCircle } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  const handleBookAppointment = () => {
    window.open("https://forms.gle/XsvtBWLNAWkJsj4bA", "_blank")
  }

  const serviceSteps = [
    {
      step: 1,
      title: "Book an Appointment",
      description:
        "Choose your preferred service and schedule a convenient time through our booking form or call us directly.",
      icon: <Calendar className="w-12 h-12 text-purple-600" />,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      step: 2,
      title: "We Contact You",
      description:
        "Our team will call you within 2 hours to confirm your appointment details and answer any questions.",
      icon: <Phone className="w-12 h-12 text-pink-600" />,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      step: 3,
      title: "We Arrive at Your Place",
      description:
        "Our professional beautician arrives at your doorstep with all necessary equipment and premium products.",
      icon: <MapPin className="w-12 h-12 text-rose-600" />,
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      step: 4,
      title: "You Are Happy & Beautiful",
      description: "Enjoy your transformation! We ensure you're completely satisfied with our service and results.",
      icon: <CheckCircle className="w-12 h-12 text-green-600" />,
      image: "/placeholder.svg?height=200&width=300",
    },
  ]

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-rose-50">
        <div className="container mx-auto px-4 py-20">
          {/* Hero Section */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-6">
              About Sony Beauty Salon
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Bringing professional beauty services to your doorstep with passion, expertise, and dedication to
              excellence.
            </p>
          </motion.div>

          {/* Story Section */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="mb-20"
          >
            <Card className="p-8 md:p-12">
              <CardContent>
                <h2 className="text-3xl font-bold text-gray-800 mb-6">Our Story</h2>
                <div className="grid md:grid-cols-2 gap-8 items-center">
                  <div>
                    <p className="text-gray-600 mb-4">
                      Founded with a vision to make professional beauty services accessible to everyone, Sony Beauty
                      Salon has been transforming lives through the art of beauty for over a decade.
                    </p>
                    <p className="text-gray-600 mb-4">
                      We believe that everyone deserves to feel beautiful and confident. That's why we bring our
                      expertise directly to your home, creating a comfortable and personalized experience that fits your
                      lifestyle.
                    </p>
                    <p className="text-gray-600">
                      Our team of certified professionals uses only the finest products and latest techniques to ensure
                      you receive the highest quality service every time.
                    </p>
                  </div>
                  <div className="bg-gradient-to-br from-pink-100 to-purple-100 rounded-lg p-8 text-center">
                    <h3 className="text-2xl font-bold text-purple-600 mb-4">10+ Years</h3>
                    <p className="text-gray-600">of Excellence in Beauty Services</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* How It Works Section */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="mb-20"
          >
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-800 mb-4">How Our Service Works</h2>
              <p className="text-xl text-gray-600">Simple steps to get your perfect beauty treatment at home</p>
            </div>

            <div className="space-y-12">
              {serviceSteps.map((step, index) => (
                <motion.div
                  key={step.step}
                  initial={{ x: index % 2 === 0 ? -50 : 50, opacity: 0 }}
                  whileInView={{ x: 0, opacity: 1 }}
                  transition={{ delay: index * 0.2, duration: 0.8 }}
                  className={`flex flex-col ${index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"} items-center gap-8`}
                >
                  <div className="flex-1">
                    <Card className="p-8 h-full">
                      <CardContent>
                        <div className="flex items-center mb-6">
                          <div className="bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-xl mr-4">
                            {step.step}
                          </div>
                          <div className="flex-shrink-0 mr-4">{step.icon}</div>
                        </div>
                        <h3 className="text-2xl font-bold text-gray-800 mb-4">{step.title}</h3>
                        <p className="text-gray-600 text-lg leading-relaxed">{step.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                  <div className="flex-1">
                    <div className="relative">
                      <img
                        src={step.image || "/placeholder.svg"}
                        alt={step.title}
                        className="w-full h-64 object-cover rounded-lg shadow-lg"
                      />
                      <div className="absolute inset-0 bg-gradient-to-r from-pink-500/20 to-purple-600/20 rounded-lg"></div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Stats Section */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="mb-20"
          >
            <div className="grid md:grid-cols-4 gap-6">
              {[
                { icon: <Users className="w-8 h-8" />, number: "5000+", label: "Happy Customers" },
                { icon: <Award className="w-8 h-8" />, number: "50+", label: "Services Offered" },
                { icon: <Clock className="w-8 h-8" />, number: "24/7", label: "Service Available" },
                { icon: <Heart className="w-8 h-8" />, number: "100%", label: "Satisfaction Rate" },
              ].map((stat, index) => (
                <Card key={index} className="text-center p-6">
                  <CardContent className="pt-6">
                    <div className="flex justify-center text-purple-600 mb-4">{stat.icon}</div>
                    <h3 className="text-3xl font-bold text-gray-800 mb-2">{stat.number}</h3>
                    <p className="text-gray-600">{stat.label}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </motion.div>

          {/* Mission & Vision */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="grid md:grid-cols-2 gap-8 mb-16"
          >
            <Card className="p-8">
              <CardContent>
                <h3 className="text-2xl font-bold text-pink-600 mb-4">Our Mission</h3>
                <p className="text-gray-600">
                  To provide exceptional beauty services that enhance natural beauty and boost confidence, delivered
                  with professionalism and care in the comfort of your own space.
                </p>
              </CardContent>
            </Card>

            <Card className="p-8">
              <CardContent>
                <h3 className="text-2xl font-bold text-purple-600 mb-4">Our Vision</h3>
                <p className="text-gray-600">
                  To be the leading home beauty service provider, setting new standards in quality, convenience, and
                  customer satisfaction while making beauty accessible to all.
                </p>
              </CardContent>
            </Card>
          </motion.div>

          {/* Call to Action */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 1.0, duration: 0.8 }}
            className="text-center"
          >
            <Card className="p-8 bg-gradient-to-r from-pink-100 to-purple-100">
              <CardContent>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Ready to Experience Our Service?</h3>
                <p className="text-gray-600 mb-6">
                  Book your appointment today and let us bring the salon experience to your home!
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleBookAppointment}
                    className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-8 py-3 rounded-lg font-semibold"
                  >
                    Book Appointment
                  </motion.button>
                  <Link href="/packages">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="border-2 border-purple-300 text-purple-600 hover:bg-purple-50 px-8 py-3 rounded-lg font-semibold"
                    >
                      View Packages
                    </motion.button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </PageTransition>
  )
}
