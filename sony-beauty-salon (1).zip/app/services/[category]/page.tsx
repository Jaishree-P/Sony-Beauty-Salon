"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { PageTransition } from "../../components/page-transition"
import { services } from "../../data/services"
import { useParams, useSearchParams } from "next/navigation"
import { Clock, IndianRupee, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useEffect, useState } from "react"

export default function CategoryPage() {
  const params = useParams()
  const searchParams = useSearchParams()
  const [highlightedService, setHighlightedService] = useState<string | null>(null)

  const categoryId = Array.isArray(params.category) ? params.category[0] : params.category
  const serviceId = searchParams.get("service")

  const category = services.find((cat) => cat.id === categoryId)

  const handleBookAppointment = () => {
    window.open("https://forms.gle/XsvtBWLNAWkJsj4bA", "_blank")
  }

  useEffect(() => {
    if (serviceId) {
      setHighlightedService(serviceId)
      // Scroll to the highlighted service after a short delay
      setTimeout(() => {
        const element = document.getElementById(serviceId)
        if (element) {
          element.scrollIntoView({ behavior: "smooth", block: "center" })
        }
      }, 500)
    }
  }, [serviceId])

  if (!category) {
    return (
      <PageTransition>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-800 mb-4">Category Not Found</h1>
            <Link href="/services">
              <Button>Back to Services</Button>
            </Link>
          </div>
        </div>
      </PageTransition>
    )
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-rose-50">
        <div className="container mx-auto px-4 py-20">
          {/* Back Button */}
          <motion.div
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <Link href="/services">
              <Button variant="ghost" className="text-purple-600 hover:text-purple-700">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Services
              </Button>
            </Link>
          </motion.div>

          {/* Category Header */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <div className="text-6xl mb-4">{category.icon}</div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-6">
              {category.name}
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">{category.description}</p>
          </motion.div>

          {/* Services List */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {category.subServices.map((service, index) => (
              <motion.div
                key={service.id}
                id={service.id}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: index * 0.1, duration: 0.8 }}
              >
                <Card
                  className={`h-full hover:shadow-lg transition-all duration-300 ${
                    highlightedService === service.id ? "ring-2 ring-purple-500 shadow-lg scale-105" : ""
                  }`}
                >
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <h3 className="text-xl font-bold text-gray-800">{service.name}</h3>
                      {highlightedService === service.id && (
                        <Badge className="bg-purple-500 text-white">Featured</Badge>
                      )}
                    </div>

                    <p className="text-gray-600 mb-4">{service.description}</p>

                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center text-gray-500">
                        <Clock className="w-4 h-4 mr-1" />
                        <span className="text-sm">{service.duration}</span>
                      </div>
                      <div className="flex items-center text-purple-600 font-bold">
                        <IndianRupee className="w-4 h-4" />
                        <span>{service.price.replace("₹", "")}</span>
                      </div>
                    </div>

                    <Button
                      className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                      onClick={handleBookAppointment}
                    >
                      Book Now
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </PageTransition>
  )
}
