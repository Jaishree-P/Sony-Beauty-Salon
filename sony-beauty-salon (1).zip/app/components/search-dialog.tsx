"use client"

import { useState, useMemo } from "react"
import { useRouter } from "next/navigation"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, ArrowRight } from "lucide-react"
import { services } from "../data/services"

interface SearchDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function SearchDialog({ open, onOpenChange }: SearchDialogProps) {
  const [query, setQuery] = useState("")
  const router = useRouter()

  const searchResults = useMemo(() => {
    if (!query.trim()) return []

    const results: Array<{ id: string; name: string; category: string }> = []

    services.forEach((category) => {
      category.subServices.forEach((service) => {
        if (service.name.toLowerCase().includes(query.toLowerCase())) {
          results.push({
            id: service.id,
            name: service.name,
            category: category.name,
          })
        }
      })
    })

    return results.slice(0, 8) // Limit to 8 results
  }, [query])

  const handleSelectService = (serviceId: string, categoryName: string) => {
    const categorySlug = categoryName.toLowerCase().replace(/\s+/g, "-")
    router.push(`/services/${categorySlug}?service=${serviceId}`)
    onOpenChange(false)
    setQuery("")
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Search Services
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Input
            placeholder="Search for beauty services..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full"
            autoFocus
          />

          {query && (
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {searchResults.length > 0 ? (
                searchResults.map((result) => (
                  <Button
                    key={result.id}
                    variant="ghost"
                    className="w-full justify-between text-left h-auto p-3"
                    onClick={() => handleSelectService(result.id, result.category)}
                  >
                    <div>
                      <div className="font-medium">{result.name}</div>
                      <div className="text-sm text-gray-500">{result.category}</div>
                    </div>
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                ))
              ) : (
                <div className="text-center py-4 text-gray-500">No services found for "{query}"</div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
