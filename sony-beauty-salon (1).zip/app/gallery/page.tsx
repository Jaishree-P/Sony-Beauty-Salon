"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { PageTransition } from "../components/page-transition"
import { Eye, Heart, Share2 } from "lucide-react"
import { useState } from "react"

export default function GalleryPage() {
  const [selectedCategory, setSelectedCategory] = useState("all")

  const handleBookAppointment = () => {
    window.open("https://forms.gle/XsvtBWLNAWkJsj4bA", "_blank")
  }

  // Sample gallery images - replace with actual work images
  const galleryImages = [
    {
      id: 1,
      src: "/placeholder.svg?height=400&width=400",
      title: "Bridal Makeup",
      category: "makeup",
      description: "Complete bridal makeover with traditional look",
    },
    {
      id: 2,
      src: "/placeholder.svg?height=400&width=400",
      title: "Hair Styling",
      category: "hair",
      description: "Professional hair styling and treatment",
    },
    {
      id: 3,
      src: "/placeholder.svg?height=400&width=400",
      title: "Facial Treatment",
      category: "facial",
      description: "Glowing skin after facial treatment",
    },
    {
      id: 4,
      src: "/placeholder.svg?height=400&width=400",
      title: "Manicure & Pedicure",
      category: "nails",
      description: "Beautiful nail art and care",
    },
    {
      id: 5,
      src: "/placeholder.svg?height=400&width=400",
      title: "Party Makeup",
      category: "makeup",
      description: "Glamorous party look",
    },
    {
      id: 6,
      src: "/placeholder.svg?height=400&width=400",
      title: "Hair Color",
      category: "hair",
      description: "Professional hair coloring service",
    },
    {
      id: 7,
      src: "/placeholder.svg?height=400&width=400",
      title: "Eyebrow Threading",
      category: "threading",
      description: "Perfect eyebrow shaping",
    },
    {
      id: 8,
      src: "/placeholder.svg?height=400&width=400",
      title: "Korean Facial",
      category: "facial",
      description: "Premium Korean facial treatment",
    },
    {
      id: 9,
      src: "/placeholder.svg?height=400&width=400",
      title: "Nail Art",
      category: "nails",
      description: "Creative nail art designs",
    },
  ]

  const categories = [
    { id: "all", label: "All Work" },
    { id: "makeup", label: "Makeup" },
    { id: "hair", label: "Hair" },
    { id: "facial", label: "Facials" },
    { id: "nails", label: "Nails" },
    { id: "threading", label: "Threading" },
  ]

  const filteredImages =
    selectedCategory === "all" ? galleryImages : galleryImages.filter((img) => img.category === selectedCategory)

  return (
    <PageTransition>
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-rose-50">
        <div className="container mx-auto px-4 py-20">
          {/* Hero Section */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-6">
              Our Work Gallery
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover the transformations we've created for our clients. Each image tells a story of beauty,
              confidence, and excellence.
            </p>
          </motion.div>

          {/* Category Filter */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="flex flex-wrap justify-center gap-4 mb-12"
          >
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                className={`${
                  selectedCategory === category.id
                    ? "bg-gradient-to-r from-pink-500 to-purple-600 text-white"
                    : "border-purple-300 text-purple-600 hover:bg-purple-50"
                }`}
                onClick={() => setSelectedCategory(category.id)}
              >
                {category.label}
              </Button>
            ))}
          </motion.div>

          {/* Gallery Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {filteredImages.map((image, index) => (
              <motion.div
                key={image.id}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: index * 0.1, duration: 0.8 }}
              >
                <Card className="group overflow-hidden hover:shadow-xl transition-all duration-300">
                  <div className="relative overflow-hidden">
                    <img
                      src={image.src || "/placeholder.svg"}
                      alt={image.title}
                      className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex gap-4">
                        <Button size="sm" variant="secondary" className="rounded-full">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="secondary" className="rounded-full">
                          <Heart className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="secondary" className="rounded-full">
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{image.title}</h3>
                    <p className="text-gray-600 text-sm">{image.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Call to Action */}
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="text-center"
          >
            <Card className="p-8 bg-gradient-to-r from-pink-100 to-purple-100">
              <CardContent>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">Ready for Your Transformation?</h3>
                <p className="text-gray-600 mb-6">Book your appointment today and let us create your perfect look!</p>
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-8 py-3"
                  onClick={handleBookAppointment}
                >
                  Book Appointment
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </PageTransition>
  )
}
