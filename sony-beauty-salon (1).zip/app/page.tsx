"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Star, Sparkles, Heart, Crown } from "lucide-react"
import Link from "next/link"
import { BackgroundAnimation } from "./components/background-animation"

export default function HomePage() {
  const handleBookAppointment = () => {
    window.open("https://forms.gle/XsvtBWLNAWkJsj4bA", "_blank")
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      <BackgroundAnimation />

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10"
      >
        {/* Hero Section */}
        <section className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-50 via-purple-50 to-rose-50">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              <h1 className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-pink-600 via-purple-600 to-rose-600 bg-clip-text text-transparent mb-6">
                Sony Beauty Salon
              </h1>
              <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
                Transform your beauty with our premium home service salon experience. Professional treatments delivered
                to your doorstep.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-8 py-4 text-lg"
                  onClick={handleBookAppointment}
                >
                  Book Appointment
                </Button>
                <Link href="/packages">
                  <Button
                    variant="outline"
                    size="lg"
                    className="border-2 border-purple-300 text-purple-600 hover:bg-purple-50 px-8 py-4 text-lg"
                  >
                    View Packages
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl font-bold text-gray-800 mb-4">Why Choose Sony Beauty Salon?</h2>
              <p className="text-xl text-gray-600">Experience luxury beauty treatments in the comfort of your home</p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: <Crown className="w-12 h-12 text-purple-600" />,
                  title: "Premium Quality",
                  description: "Professional-grade products and expert techniques for exceptional results",
                },
                {
                  icon: <Heart className="w-12 h-12 text-pink-600" />,
                  title: "Home Service",
                  description: "Enjoy luxury treatments in the comfort and privacy of your own space",
                },
                {
                  icon: <Sparkles className="w-12 h-12 text-rose-600" />,
                  title: "Expert Stylists",
                  description: "Certified professionals with years of experience in beauty and wellness",
                },
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ y: 50, opacity: 0 }}
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{ delay: index * 0.2, duration: 0.8 }}
                >
                  <Card className="text-center p-8 hover:shadow-lg transition-shadow duration-300">
                    <CardContent className="pt-6">
                      <div className="flex justify-center mb-4">{feature.icon}</div>
                      <h3 className="text-2xl font-semibold mb-4 text-gray-800">{feature.title}</h3>
                      <p className="text-gray-600">{feature.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Popular Packages Preview */}
        <section className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl font-bold text-gray-800 mb-4">Popular Packages</h2>
              <p className="text-xl text-gray-600">Curated beauty packages for every occasion</p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                { name: "Basic Pack", price: "₹1,699", popular: false },
                { name: "Radiance Pack", price: "₹1,899", popular: true },
                { name: "Royal Glow Pack", price: "₹2,999", popular: false },
              ].map((pkg, index) => (
                <motion.div
                  key={index}
                  initial={{ y: 50, opacity: 0 }}
                  whileInView={{ y: 0, opacity: 1 }}
                  transition={{ delay: index * 0.2, duration: 0.8 }}
                >
                  <Card className={`relative ${pkg.popular ? "ring-2 ring-purple-500 shadow-lg" : ""}`}>
                    {pkg.popular && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <span className="bg-purple-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                          Most Popular
                        </span>
                      </div>
                    )}
                    <CardContent className="p-8 text-center">
                      <h3 className="text-2xl font-bold mb-2">{pkg.name}</h3>
                      <p className="text-3xl font-bold text-purple-600 mb-4">{pkg.price}</p>
                      <div className="flex justify-center mb-4">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <Link href="/packages">
                        <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700">
                          View Details
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </motion.div>
    </div>
  )
}
