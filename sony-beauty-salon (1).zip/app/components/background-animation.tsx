"use client"

import { motion } from "framer-motion"

export function BackgroundAnimation() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Floating Bubbles with varied sizes and colors - Continuous Motion */}
      {[...Array(30)].map((_, i) => (
        <motion.div
          key={`bubble-${i}`}
          className={`absolute rounded-full ${
            i % 4 === 0
              ? "bg-gradient-to-r from-pink-200 to-rose-200"
              : i % 4 === 1
                ? "bg-gradient-to-r from-purple-200 to-indigo-200"
                : i % 4 === 2
                  ? "bg-gradient-to-r from-rose-200 to-pink-200"
                  : "bg-gradient-to-r from-indigo-200 to-purple-200"
          } opacity-40`}
          style={{
            width: Math.random() * 120 + 30,
            height: Math.random() * 120 + 30,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -200, -400, -200, 0],
            x: [0, Math.random() * 300 - 150, Math.random() * 200 - 100, Math.random() * 250 - 125, 0],
            scale: [1, 1.4, 1.1, 1.3, 1],
            rotate: [0, 180, 360, 540, 720],
            opacity: [0.2, 0.6, 0.3, 0.5, 0.2],
          }}
          transition={{
            duration: Math.random() * 20 + 25,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
            repeatType: "loop",
          }}
        />
      ))}

      {/* Sparkle Effects - Continuous */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={`sparkle-${i}`}
          className="absolute w-3 h-3 bg-gradient-to-r from-yellow-300 to-pink-300 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            scale: [0, 1.5, 0.5, 1, 0],
            opacity: [0, 1, 0.5, 0.8, 0],
            rotate: [0, 180, 360, 540, 720],
            x: [0, Math.random() * 100 - 50, Math.random() * 80 - 40, 0],
            y: [0, Math.random() * 100 - 50, Math.random() * 80 - 40, 0],
          }}
          transition={{
            duration: Math.random() * 4 + 3,
            repeat: Number.POSITIVE_INFINITY,
            delay: Math.random() * 2,
            repeatType: "loop",
          }}
        />
      ))}

      {/* Large Gradient Orbs - Continuous Motion */}
      <motion.div
        className="absolute w-96 h-96 rounded-full bg-gradient-to-r from-pink-300 via-purple-300 to-rose-300 opacity-25 blur-3xl"
        animate={{
          x: [0, 200, -100, 150, 0],
          y: [0, -150, 100, -80, 0],
          scale: [1, 1.3, 0.8, 1.1, 1],
          rotate: [0, 90, 180, 270, 360],
        }}
        transition={{
          duration: 30,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
          repeatType: "loop",
        }}
        style={{ top: "5%", left: "5%" }}
      />

      <motion.div
        className="absolute w-80 h-80 rounded-full bg-gradient-to-r from-indigo-300 via-purple-300 to-pink-300 opacity-20 blur-3xl"
        animate={{
          x: [0, -150, 120, -80, 0],
          y: [0, 120, -100, 90, 0],
          scale: [1, 0.7, 1.4, 0.9, 1],
          rotate: [0, -90, -180, -270, -360],
        }}
        transition={{
          duration: 35,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
          repeatType: "loop",
        }}
        style={{ bottom: "5%", right: "5%" }}
      />

      <motion.div
        className="absolute w-64 h-64 rounded-full bg-gradient-to-r from-rose-300 via-pink-300 to-purple-300 opacity-30 blur-2xl"
        animate={{
          x: [0, 150, -120, 100, 0],
          y: [0, -100, 150, -120, 0],
          scale: [1, 1.5, 0.8, 1.2, 1],
          rotate: [0, 120, 240, 360, 480],
        }}
        transition={{
          duration: 25,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
          repeatType: "loop",
        }}
        style={{ top: "50%", left: "50%" }}
      />

      {/* Floating Hearts - Continuous */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={`heart-${i}`}
          className="absolute text-pink-300 opacity-50"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            fontSize: Math.random() * 25 + 20,
          }}
          animate={{
            y: [0, -300, -150, -250, 0],
            x: [0, Math.random() * 150 - 75, Math.random() * 100 - 50, 0],
            rotate: [0, 360, 720, 1080],
            scale: [1, 1.8, 1.2, 1.5, 1],
            opacity: [0.3, 0.7, 0.4, 0.6, 0.3],
          }}
          transition={{
            duration: Math.random() * 25 + 30,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
            repeatType: "loop",
          }}
        >
          💖
        </motion.div>
      ))}

      {/* Beauty Icons - Continuous Motion */}
      {["✨", "💅", "💄", "🌸", "🦋", "💎", "🌺", "💐", "🎀", "👑"].map((icon, i) => (
        <motion.div
          key={`icon-${i}`}
          className="absolute text-purple-300 opacity-40"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            fontSize: Math.random() * 20 + 25,
          }}
          animate={{
            y: [0, -200, -100, -180, 0],
            x: [0, Math.random() * 200 - 100, Math.random() * 150 - 75, 0],
            rotate: [0, 360, 720, 1080, 1440],
            scale: [1, 1.4, 0.8, 1.2, 1],
            opacity: [0.2, 0.6, 0.3, 0.5, 0.2],
          }}
          transition={{
            duration: Math.random() * 30 + 35,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
            repeatType: "loop",
          }}
        >
          {icon}
        </motion.div>
      ))}

      {/* Additional Floating Elements */}
      {[...Array(15)].map((_, i) => (
        <motion.div
          key={`extra-${i}`}
          className="absolute w-4 h-4 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-30"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -250, -50, -200, 0],
            x: [0, Math.random() * 180 - 90, Math.random() * 120 - 60, 0],
            scale: [0.5, 2, 1, 1.5, 0.5],
            opacity: [0.1, 0.5, 0.2, 0.4, 0.1],
          }}
          transition={{
            duration: Math.random() * 20 + 20,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
            repeatType: "loop",
          }}
        />
      ))}
    </div>
  )
}
